package bg.tusofia.vvps.ticketsystem.ticket;

public enum TicketState {
    SOLD,
    RESERVED,
    AVAILABLE
}
