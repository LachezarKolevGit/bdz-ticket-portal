package bg.tusofia.vvps.ticketsystem.train;

public record TrainStationDTO(Long id, String name, Double latitude, Double longitude) {

}
