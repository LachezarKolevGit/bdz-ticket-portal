package bg.tusofia.vvps.ticketsystem.traincarriage;

public record TrainCarriageDTO(TrainCarriageType trainCarriageType, int totalSeats) {
}
