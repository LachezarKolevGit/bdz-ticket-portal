package bg.tusofia.vvps.ticketsystem.user;

public enum Role {
    ROLE_CLIENT,
    ROLE_ADMINISTRATOR
}
