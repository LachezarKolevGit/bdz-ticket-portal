package bg.tusofia.vvps.ticketsystem.traincarriage.seat;

public enum SeatState {
    SOLD,
    AVAILABLE,
    RESERVED
}
