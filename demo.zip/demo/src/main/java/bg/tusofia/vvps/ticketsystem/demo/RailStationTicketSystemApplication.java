package bg.tusofia.vvps.ticketsystem.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RailStationTicketSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(RailStationTicketSystemApplication.class, args);
	}

}
